# Smoke test mínimo offline.
